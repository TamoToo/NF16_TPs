#ifndef EXERCICE1_H_INCLUDED
#define EXERCICE1_H_INCLUDED

void EXO1_question1() ;

void EXO1_question2() ;

void EXO1_question3() ;

void EXO1_question4() ;

void EXO1_question5() ;

void EXO1_question6() ;

void EXO1_question7() ;


#endif // EXERCICE1_H_INCLUDED
