#ifndef EXERCICE5_H_INCLUDED
#define EXERCICE5_H_INCLUDED

void EXO5_question1() ;

void EXO5_question2() ;

void EXO5_question3() ;


#endif // EXERCICE5_H_INCLUDED
