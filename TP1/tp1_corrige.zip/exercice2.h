#ifndef EXERCICE2_H_INCLUDED
#define EXERCICE2_H_INCLUDED

void EXO2_question1() ;

void EXO2_question2() ;

void EXO2_question3() ;

void EXO2_question4() ;

#endif // EXERCICE2_H_INCLUDED
