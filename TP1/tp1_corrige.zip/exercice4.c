#include <stdio.h>
#include <stdlib.h>

void permuter(int *a,int *b) {
    int tmp;
    tmp = *a;
    *a = *b;
    *b = tmp;
}

void EXO4_question1() {
    /* Ecrire une fonction qui permute les valeurs de ses deux param�tres. Tester cette fonction par un appel depuis votre programme principal. */
    int nombre1, nombre2;

    printf("nombre 1 ? ");
    scanf("%d",&nombre1);
    printf("nombre 2 ? ");
    scanf("%d",&nombre2);
    printf("\nau depart : nombre1=%d   nombre2=%d",nombre1,nombre2);
    permuter(&nombre1, &nombre2);
    printf("\npermutation : nombre1=%d   nombre2=%d",nombre1,nombre2);

}

void EXO4_question2() {
    /* Pourquoi dans la question 4.1 utilise-t-on des pointeurs ? Aurait-on pu utiliser des entiers ? Justifier. */
    printf("Reponse : comme les valeurs des parametres passes a la fonction sont modifiees dans la fonction et que l'on veut garder");
    printf(" ces modifcations en retour de la fonction, alors il faut effectuer un passage des parametres par adresse et non par valeur.\n");
}

void EXO4_question3() {
    /* Ecrire un programme qui d�clare deux variables i et j; la premi�re (i) sera une variable de type entier, la seconde (j) sera une variable de type pointeur sur entier.
       C'est-�-dire que j contiendra une valeur qui sera l'adresse (emplacement m�moire) d'un entier. Affecter � l'entier i la valeur 5,
       affecter � l'adresse j l'adresse de l'entier i, afficher l'entier i et le contenu de ce qui est point� par la variable j. */
    int i;
    int *j;

    i=5;
    j = &i;
    printf("i = %d",i);
    printf("\ncontenu de j = %d",*j);
}

void EXO4_question4() {
    /* Modifier le programme pr�c�dent en ajoutant � la fin les instructions suivantes : incr�menter la donn�e point�e par la variable j, afficher i, multiplier i par 5,
       afficher la donn�e point�e par j, incr�menter l'adresse j et afficher de nouveau la donn�e point�e par j. */
    int i;
    int *j;

    i=5;
    j = &i;
    printf("i = %d",i);
    printf("\ncontenu de j = %d",*j);

    (*j)++;
    printf("\napres (*j)++, i = %d",i);

    i*=5;
    printf("\napres i*=5, contenu de j = %d",*j);

    j++;
    printf("\napres j++, contenu de j = %d",*j);
}

void EXO4_question5() {
    /* Reprendre l'exercice 3.3 avec la notation en pointeur pour la ligne. */
    int tableauInt[3][4] = {{12,13,14,15},{16,17,18,19},{20,21,22,23}};
    int index_ligne,index_colonne;

    for (index_ligne = 0; index_ligne<3; index_ligne++) {
        printf("\n");
        for (index_colonne = 0; index_colonne<4; index_colonne++) {
            printf("   %d",(*(tableauInt+index_ligne))[index_colonne]);
        }
    }

}

void EXO4_question6() {
    /* Reprendre l'exercice 3.3 avec une notation en pointeur uniquement. */
    int tableauInt[3][4] = {{12,13,14,15},{16,17,18,19},{20,21,22,23}};
    int index_ligne,index_colonne;

    for (index_ligne = 0; index_ligne<3; index_ligne++) {
        printf("\n");
        for (index_colonne = 0; index_colonne<4; index_colonne++) {
            printf("   %d",*(*(tableauInt+index_ligne)+index_colonne));
        }
    }
}

void EXO4_question7() {
    /* Ecrire un programme qui lit une liste de Nb nombres, la d�cale d'un cran vers le haut (le premier doit se retrouver en dernier),
       l'affiche puis la d�cale vers le bas. Les nombres doivent �tre stock�s dans un tableau avec une notation en pointeurs. */
    int nb,i;
    printf("donnez NB : ");
    scanf("%d",&nb);

    //lecture
    int *YO = malloc(nb*sizeof(int));
    for (i=0 ; i<nb ; i++){
        printf("Donnez le nombre numero %d\n",i+1);
        scanf("%d",YO+i);
    }

    //affichage
    printf("\n\nTableau initial\n");
    for (i=0 ; i<nb ; i++){
    printf("  %d",*(YO+i));
    }

    int temp;
    temp = *YO;
    //decalage vers le haut
    for (i=0 ; i<nb-1 ; i++){
       *(YO+i) = *(YO+i+1);
    }
    *(YO+nb-1) = temp;

    //affichage
    printf("\n\nTableau apres decalage vers le haut\n\n");
    for (i=0 ; i<nb ; i++){
    printf("  %d",*(YO+i));
    }

    //d�calage vers le bas
    temp = *(YO+nb-1);
     for (i=nb-1 ; i>0 ; i--){
       *(YO+i) = *(YO+i-1);
    }
    *YO = temp;


    //affichage
    printf("\n\nTableau apres decalage vers le bas\n\n");
    for (i=0 ; i<nb ; i++){
    printf("  %d",*(YO+i));
    }

}
