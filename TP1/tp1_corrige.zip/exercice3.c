#include <stdio.h>
#include <stdlib.h>
#include "exercice3.h"

void EXO3_question1() {
    /* D�clarer un tableau de 10 entiers, une variable de contr�le de boucle de type entier; puis r�aliser l'initialisation du tableau avec la valeur 0 � l'aide d'une boucle. */
    int tableauInt[10];
    int i;
    for (i=0;i<10;i++) {
        tableauInt[i] = 0;
    }
}

void EXO3_question2() {
    /* D�clarer un tableau de 5 entiers en l'initialisant � la d�claration avec les valeurs d�croissantes allant de 4 � 0. */
    int tableauInt[5] = {4,3,2,1,0};
}

void EXO3_question3() {
    /* D�clarer un tableau de dimension 2, de 3 lignes et 4 colonnes. Initialiser les cases du tableau avec des valeurs allant de 12 � 23,
       la premi�re ligne contiendra les valeurs 12, 13, 14, 15; la deuxi�me 16, 17, 18, 19; la troisi�me 20, 21, 22, 23; afficher les cases du tableau
       en utilisant la notation indic�e. */
    int tableauInt[3][4] = {{12,13,14,15},{16,17,18,19},{20,21,22,23}};
    int index_ligne, index_colonne;

    for (index_ligne = 0; index_ligne<3; index_ligne++) {
        printf("\n");
        for (index_colonne = 0; index_colonne<4; index_colonne++) {
            printf("   %d",tableauInt[index_ligne][index_colonne]);
        }
    }
}

void EXO3_question4() {
    /* Faire le calcul de multiplication d'une matrice (M lignes, L colonnes) par une matrice (L, N) : r�sultat (M,N). */
    int matrice_ml[M][L]={{5,1,8},{2,3,6},{3,0,1},{7,2,4}};
    int matrice_ln[L][N]={{1,2,0,4,6},{4,4,3,6,1},{0,1,4,3,1}};
    int matrice_mn[M][N];
    int index_ligne, index_colonne, k;

    printf("\n\nmatrice (M,L) :");
    /* affichage matrice ml */
    for (index_ligne = 0; index_ligne<M; index_ligne++) {
        printf("\n");
        for (index_colonne = 0; index_colonne<L; index_colonne++) {
            printf("\t%d",matrice_ml[index_ligne][index_colonne]);
        }
    }

    printf("\n\nmatrice (L,N) :");
    /* affichage matrice ln */
    for (index_ligne = 0; index_ligne<L; index_ligne++) {
        printf("\n");
        for (index_colonne = 0; index_colonne<N; index_colonne++) {
            printf("\t%d",matrice_ln[index_ligne][index_colonne]);
        }
    }

    /* calcul matrice mn */
    for (index_ligne = 0; index_ligne<M; index_ligne++) {
        for (index_colonne = 0; index_colonne<N; index_colonne++) {
            matrice_mn[index_ligne][index_colonne] = 0;
            for (k = 0; k<L; k++) {
                matrice_mn[index_ligne][index_colonne]+=matrice_ml[index_ligne][k]*matrice_ln[k][index_colonne];
            }
        }
    }

    printf("\n\nmatrice (M,N) :");
    /* affichage matrice mn */
    for (index_ligne = 0; index_ligne<M; index_ligne++) {
        printf("\n");
        for (index_colonne = 0; index_colonne<N; index_colonne++) {
            printf("\t%d",matrice_mn[index_ligne][index_colonne]);
        }
    }

}
