#ifndef EXERCICE4_H_INCLUDED
#define EXERCICE4_H_INCLUDED

void EXO4_question1() ;

void EXO4_question2() ;

void EXO4_question3() ;

void EXO4_question4() ;

void EXO4_question5() ;

void EXO4_question6() ;

void EXO4_question7() ;

#endif // EXERCICE4_H_INCLUDED
