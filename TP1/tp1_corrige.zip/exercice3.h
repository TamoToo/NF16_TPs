#ifndef EXERCICE3_H_INCLUDED
#define EXERCICE3_H_INCLUDED

#define L 3
#define M 4
#define N 5

void EXO3_question1() ;

void EXO3_question2() ;

void EXO3_question3() ;

void EXO3_question4() ;


#endif // EXERCICE3_H_INCLUDED
