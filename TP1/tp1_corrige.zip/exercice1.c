#include <stdio.h>
#include <stdlib.h>

void EXO1_question1() {
    /* Ecrire un programme C qui lit deux r�els, les affiche, calcule leur somme et affiche le r�sultat */
    float a,b,somme;
    printf("\nVeuillez entrer le premier reel : ");
    scanf("%f",&a);
    printf("\nVeuillez entrer le deuxieme reel : ");
    scanf("%f",&b);
    somme = a+b;
    printf("\nLa somme de a et b est : %.2f \n",somme);
}

void EXO1_question2() {
    /* Ecrire un programme C qui permute les valeurs de deux variables lues au clavier. */
    int a,b,tmp;
    printf("\nVeuillez entrer le premier nombre : ");
    scanf("%d",&a);
    printf("\nVeuillez entrer le deuxi�me nombre : ");
    scanf("%d",&b);
    tmp = b ;
    b = a ;
    a = tmp;
    printf("\nLa valeur de a est : %d et la valeur de b est %d \n",a,b);
}

void EXO1_question3() {
    /* Ecrire un programme C qui calcule le pourcentage x d'un nombre y. Ce nombre ainsi que le pourcentage sont saisis au clavier. */
    float a,b,pourcentage;
    printf("\nVeuillez entrer le nombre : ");
    scanf("%f",&a);
    printf("\nVeuillez entrer le poucentage souhaite : ");
    scanf("%f",&b);
    pourcentage = (a * b) / 100;
    printf("\nLa valeur du resultat est %.2f \n",pourcentage);
}

void EXO1_question4() {
    /* Ecrire un programme C qui donne une temp�rature en degr� Celsius � partir d'une temp�rature Fahrenheit (C = (5/9) * (F - 32)) */
    float a,b;
    printf("\nVeuillez entrer la temperature en fahrenheit : ");
    scanf("%f",&a);
    b = (a-32)*(5.0/9.0);
    printf("\nLa temperature en celsius est %.2f \n",b);
}

void EXO1_question5() {
    /* Ecrire un programme C qui lit un entier et l'affiche en d�cimal, en octal et en hexad�cimal */
    int a;
    printf("\nVeuillez entrer le nombre : ");
    scanf("%d",&a);
    printf("\nLa valeur en decimal est %d",a);
    printf("\nLa valeur en octal est %o",a);
    printf("\nLa valeur en hexadecimal est %x",a);
}

void EXO1_question6() {
    /* Ecrire un programme C qui lit un entier et affiche � l'�cran si c'est 0, un nombre pair ou un nombre impair */
    int a;
    printf("\nVeuillez entrer le nombre : ");
    scanf("%d",&a);
    if (a == 0)
        printf("\nLe nombre est 0");
    else{
        if (a%2 == 0)
            printf("\nLe nombre %d est pair",a);
        else
            printf("\nLe nombre %d est impair",a);
    }
}

void EXO1_question7() {
    /* Ecrire un programme C qui d�clare un caract�re (type char) et l'initialise une premi�re fois avec le caract�re '5', puis avec le caract�re correspondant au code ASCII 96. */
    char car = '5';
    printf("\ncaractere = %c",car);
    car = 96;
    printf("\ncaractere = %c",car);

}
