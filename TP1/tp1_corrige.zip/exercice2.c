#include <stdio.h>
#include <stdlib.h>

void EXO2_question1() {
    /* Ecrire un programme C qui teste si un caract�re saisi au clavier est un chiffre ou si c'est un caract�re compris entre 'a' et 'z' ou encore entre 'A' et 'Z' */
    char car;

    printf("\nentrer un caractere : ");
    scanf("%c",&car);

    if (car>='0' && car<='9') {
        printf("\nvous avez saisi un chiffre");
    } else if (car>='a' && car<='z') {
        printf("\nvous avez saisi une minuscule");
    } else if (car>='A' && car<='Z') {
        printf("\nvous avez saisi une majuscule");
    } else {
        printf("\ncaractere non pris en charge");
    }

}

void EXO2_question2() {
    /* Ecrire un programme C qui lit une suite d'entiers strictement positifs et qui s'arr�te si on saisit la valeur -1 */
    int entier = -1;
    char car;
    int nb_read;

    do {
        printf("veuillez entrer le nombre : ");
        nb_read = scanf("%d",&entier);
        if (entier>-1 && nb_read>0) {
            printf("  OK\n");
        }
    } while(entier!=-1);

}

void EXO2_question3() {
    /* Ecrire un programme C qui demande "Quelle table de multiplication voulez-vous, tapez 0 (z�ro) pour sortir ?",
       qui saisit un caract�re, si le caract�re est compris entre '1' et '9' alors on fera afficher la table correspondante
       puis on r�it�rera le processus, sinon on affichera "ce n'est pas dans les possibilit�s du programme, recommencez !" et on r�it�rera le processus */
    char car;
    int table_choisie;
    int nb_read;
    int i;

    do {
        printf("\nquelle table (0 pour quitter) ? ");
        nb_read = scanf("%d",&table_choisie);
        /* on vide le buffer */
        while ((car = getchar ()) != '\n' && car != EOF);
        if(nb_read==1 && table_choisie>0 && table_choisie<10) {
            /* afficher la table */
            for (i=1;i<=10;i++) {
                printf("\n%d x %d = %d",i,table_choisie,i*table_choisie);
            }
        } else if (table_choisie != 0){
            printf("demande incorrecte !!!");
        }
    } while(table_choisie!=0);
}

void EXO2_question4() {
    /* Ecrire un programme C en utilisant l'instruction Switch qui lit un caract�re (fonction getchar()), qui affiche "un" si le caract�re '1' a �t� saisi,
       "deux" si c'est le caract�re '2', "trois" si c'est '3' et "autre caract�re" sinon */

    printf("entrer un caractere : ");
    char car = getchar ();

    switch(car) {
        case '1' :
            printf("un");
            break;
        case '2' :
            printf("deux");
            break;
        case '3' :
            printf("trois");
            break;
        default :
            printf("autre");
            break;
    }

}

