#include <stdio.h>
#include <stdlib.h>

void EXO5_question1() {
    /* Ecrire un programme C qui d�termine le nombre et la position d'une sous-cha�ne dans une cha�ne. */
    char chaine[100];
    char sousChaine[20];

    printf("Donnez la chaine : ");
    fgets(chaine, 100, stdin);
    printf("\nDonnez la sous chaine : ");
    fgets(sousChaine, 20, stdin);

    int nbOccurences=0;
    int i=0,j=0;
    int bo = 1;

    for (i=0;i<(strlen(chaine)-strlen(sousChaine)+1);i++){
        j=0;
        while ((j < strlen(sousChaine)-1) && (bo == 1)){

            if (sousChaine[j] != chaine[i+j])
                bo = 0;
            j++;
        }
        if (bo == 1){
            nbOccurences++;
            printf("\n\toccurence %d a la position %d\n",nbOccurences,i+1);
        }
        bo=1;
    }
    printf("\nnombre d'occurences est %d \n",nbOccurences);

}

void EXO5_question2() {
    /* Ecrire un programme C qui transforme tous les caract�res minuscules d'une cha�ne en caract�res majuscules. */
    char chaine[100];
    printf("Donnez la chaine : ");
    fgets(chaine, 100, stdin);
    for (int i=0;i<strlen(chaine)-1;i++){
        if ((chaine[i] >= 97) && (chaine[i]<=122)){
            chaine[i] = chaine[i] - 32;
        }
    }

    printf("\nLa nouvelle chaine : %s",chaine);
}

void EXO5_question3() {
    /* Ecrire un programme C qui permet de jouer au jeu du pendu. Le joueur 1 entre le mot, l'ordinateur l'enregistre
       et affiche une s�rie de lignes blanches pour que le joueur 2 ne puisse pas lire le mot, il affiche ensuite une s�rie d'�toiles
       qui correspond au nombre de lettres du mot � trouver. Le joueur 2 propose des caract�res jusqu'� ce qu'il ait trouv� le mot,
       ou qu'il ait perdu (nombre de coups > 10). � chaque fois que le joueur 2 propose un caract�re l'ordinateur affiche le mot avec des * et les caract�res d�j� trouv�s. */
    char chaine[35];
    char newchaine[35];
    char c;
    int bo = 1;
    int count = 0;

    printf("Entrez un mot \n");
    scanf("%s",chaine);
    getchar(); // vider le buffer

    for (int i=0;i<strlen(chaine);i++){
        newchaine[i]='*';
    }
    newchaine[strlen(chaine)]='\0';

    while (bo == 1){

        printf("%s\n",newchaine);
        printf("entrez un caractere : ");
        c=getchar();
        getchar(); // vider le buffer

        for (int i=0;i<strlen(chaine);i++){
            if (chaine[i] == c){
                newchaine[i] = c;
                count++;
            }
        }

        if (count == strlen(chaine))
            bo = 0;
    }
    printf("\n%s",chaine);
    printf("\n VOUS AVEZ GAGNE \n");
}
