#include <stdio.h>
#include <stdlib.h>
#include "exercice1.h"
#include "exercice2.h"
#include "exercice3.h"
#include "exercice4.h"
#include "exercice5.h"

int main() {

    /* Exercice 1 */
    EXO1_question1() ;
    EXO1_question2() ;
    EXO1_question3() ;
    EXO1_question4() ;
    EXO1_question5() ;
    EXO1_question6() ;
    EXO1_question7() ;

    /* Exercice 2 */
    EXO2_question1() ;
    EXO2_question2() ;
    EXO2_question3() ;
    EXO2_question4() ;

    /* Exercice 3 */
    EXO3_question1() ;
    EXO3_question2() ;
    EXO3_question3() ;
    EXO3_question4() ;

    /* Exercice 4 */
    EXO4_question1() ;
    EXO4_question2() ;
    EXO4_question3() ;
    EXO4_question4() ;
    EXO4_question5() ;
    EXO4_question6() ;
    EXO4_question7() ;

    /* Exercice 5 */
    EXO5_question1() ;
    EXO5_question2() ;
    EXO5_question3() ;

    return 0;
}
